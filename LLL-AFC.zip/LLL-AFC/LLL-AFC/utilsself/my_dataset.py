
from torch.utils.data import Dataset

class FeatureDataset(Dataset):
    def __init__(self, X, y):
        super(FeatureDataset, self).__init__()
        self.data = X
        self.targets = y

    def __len__(self):
        return self.data.shape[0]

    def __getitem__(self, index):
        return self.data[index], self.targets[index]