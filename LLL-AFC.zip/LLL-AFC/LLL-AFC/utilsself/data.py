import json
import torch
import os
import numpy as np
from sklearn.model_selection import train_test_split
from scipy.io import loadmat
import math
from .pyExt import Dict2Obj
from .my_dataset import FeatureDataset

def getDatasetInfo(dataset):
    with open("datasets/dataset_config.json", "r") as f:
        info = json.load(f)[dataset]

    return Dict2Obj(info)

def paddingData(dataset, patch_size):
    distance = patch_size // 2
    C, H, W = dataset.shape
    # center
    data = torch.zeros(size=(C, H + 2 * distance, W + 2 * distance), dtype=torch.float)
    data[:, distance:distance+H, distance:distance+W] = dataset
    # flip
    data[:, 0:distance, :] = data[:, distance:distance+distance, :].flip(1) # top
    data[:, -distance:, :] = data[:, -distance*2:-distance, :].flip(1) # bottom
    data[:, :, 0:distance] = data[:, :, distance:distance*2].flip(2) # left
    data[:, :, -distance:] = data[:, :, -distance*2:-distance].flip(2) # right
    return data

def initData(info, patch):
    data_path = os.path.join('datasets', info.path)
    # data = np.load(os.path.join(data_path, info.file_name)).astype(np.float32)
    data = loadmat(os.path.join(data_path, info.file_name))[info.mat_name].astype(np.float32) # 数据读取
    data = torch.from_numpy(data).permute(2,0,1) # [C, H, W]
    data = (data - torch.min(data)) / (torch.max(data) - torch.min(data)) # 归一化
    data = paddingData(data, patch)
    return data

def initGT(info):
    dataset_path = os.path.join('datasets', info.path)
    # gt_mat = np.load(os.path.join(dataset_path, info.gt_file_name)).astype(np.int64)
    gt_mat = loadmat(os.path.join(dataset_path, info.gt_file_name))[info.gt_mat_name].astype(np.int64)
    gt_mat = gt_mat - 1
    return torch.from_numpy(gt_mat)


def split_data(gt, train_num_target, train_rate):
    increment_train_index = []
    increment_test_index = []
    increment_val_index=[]

    for cls in range(0, gt.max() + 1):
        x, y = np.where(gt == cls)
        locations = x * gt.shape[1] + y # 位置编码

        sample_num = x.shape[0] # 某类别的样本个数
        assert train_num_target < sample_num, 'Error: train_num >= sample_num'
        if train_num_target == 0:
            train_num = math.ceil(sample_num * train_rate)
        else:
            train_num=train_num_target
        train_index, test_index = train_test_split(locations, train_size=train_num) # 划分训练集和测试集
        val_num=10
        locations1=test_index
        if(len(test_index)>val_num):
            val_index,text_index=train_test_split(locations1,test_size=len(locations)-train_num-val_num)
        else:
            val_num=train_index[:val_num]
        print(f'cls {cls}: train: {len(train_index)}, val: {len(val_index)}, test: {len(test_index)}')
        increment_train_index.extend(train_index)
        increment_test_index.extend(test_index)
        increment_val_index.extend(val_index)

    return increment_train_index, increment_test_index,increment_val_index

def getDatasetFromIndex(data, gt, index, patch):

    data_list = []
    targets_list = []

    for i in index:
        x = i // gt.shape[1]
        y = i % gt.shape[1]


        data_list.append(data[:, x : x + patch, y : y + patch])
        targets_list.append(gt[x, y])

    return FeatureDataset(torch.stack(data_list, dim=0), torch.stack(targets_list, dim=0))

def applyPCA(X, numComponents): # [C, H, W]
    from sklearn.decomposition import PCA

    X = X.permute(1, 2, 0)
    newX = np.reshape(X, (-1, X.shape[2]))
    pca = PCA(n_components=numComponents, whiten=True)
    newX = pca.fit_transform(newX)
    newX = np.reshape(newX, (X.shape[0], X.shape[1], numComponents))

    return torch.from_numpy(newX).float().permute(2, 0, 1)


def getDataset(name, patch, train_num, train_rate, pca):
    info = getDatasetInfo(name)

    data = initData(info, patch)
    gt = initGT(info)
    if pca > 0:
        data = applyPCA(data, pca)
    train_index, test_index,val_index = split_data(gt, train_num, train_rate)

    return {
        'trainset': getDatasetFromIndex(data, gt, train_index, patch),
        'testset': getDatasetFromIndex(data, gt, test_index, patch),
        'evalset': getDatasetFromIndex(data, gt, test_index, patch),
        'valset': getDatasetFromIndex(data, gt, val_index, patch),
        'balancedset': getDatasetFromIndex(data, gt, train_index, patch),
    }
