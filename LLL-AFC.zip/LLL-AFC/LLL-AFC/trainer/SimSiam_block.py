import torch.nn as nn

class SimSiam(nn.Module):
    """
    Build a SimSiam model.
    """
    def __init__(self, prev_dim = 16, dim = 16, pred_dim = 16):
        """
        prev_dim: feature dimension
        dim: after project, feature dimension
        pred_dim: hidden dimension of the predictor
        """
        super(SimSiam, self).__init__()
        self.avgpool = nn.AdaptiveAvgPool2d(1)
        self.projector = nn.Sequential(nn.Linear(prev_dim, prev_dim, bias=False),
                                       nn.BatchNorm1d(prev_dim),
                                       nn.ReLU(inplace=True),
                                       nn.Linear(prev_dim, prev_dim, bias=False),
                                       nn.BatchNorm1d(prev_dim),
                                       nn.ReLU(inplace=True),
                                       nn.Linear(prev_dim, dim, bias=False),
                                       nn.BatchNorm1d(dim, affine=False))

        self.predictor = nn.Sequential(nn.Linear(dim, pred_dim, bias=False),
                                       nn.BatchNorm1d(pred_dim),
                                       nn.ReLU(inplace=True),
                                       nn.Linear(pred_dim, dim))

    def forward(self, h1, h2):

        h1 = self.avgpool(h1)
        h1 = h1.view(h1.size(0), -1)
        h2 = self.avgpool(h2)
        h2 = h2.view(h2.size(0), -1)

        z1 = h1
        z2 = h2
        p1 = self.predictor(z1)
        p2 = self.predictor(z2)

        return p1, p2, z1.detach(), z2.detach()

