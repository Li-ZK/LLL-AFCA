
""" Training code for the 0-th phase """
import torch
import tqdm
import numpy as np
import torch.nn as nn
import torchvision
from torch.optim import lr_scheduler
from torchvision import datasets, models, transforms
from utils.misc import *
from utils.utils import tenh as tenh
from utils.process_fp import process_inputs_fp
import torch.nn.functional as F
from loss.criterion import AngularPenaltySMLoss

def fusion_aug_generate_label( y_a, y_b, iteration,the_args):

    current_total_cls_num = the_args.nb_cl_fg + iteration * the_args.nb_cl
    if iteration == 0:
        y_a, y_b = y_a, y_b
        assert y_a != y_b
        if y_a > y_b:
            tmp = y_a
            y_a = y_b
            y_b = tmp
        label_index = ((2 * current_total_cls_num - y_a - 1) * y_a) / 2 + (y_b - y_a) - 1

    else:
        y_a = y_a - (current_total_cls_num - the_args.nb_cl)
        y_b = y_b - (current_total_cls_num - the_args.nb_cl)
        assert y_a != y_b
        if y_a > y_b:
            tmp = y_a
            y_a = y_b
            y_b = tmp
        label_index = int(((2 * the_args.nb_cl - y_a - 1) * y_a) / 2 + (y_b - y_a) - 1)
    return label_index + current_total_cls_num


def incremental_train_and_eval_zeroth_phase(the_args, epochs, b1_model, ref_model, \
    tg_optimizer, tg_lr_scheduler, trainloader, testloader, valloader, iteration, start_iteration,fix_bn=False, weight_per_class=None, device=None):

    # Setting up the CUDA device
    if device is None:
        device = torch.device("cuda:0" if torch.cuda.is_available() else "gpu")
    print(device)
    for epoch in range(epochs):
        # Set the 1st branch model to the training mode
        b1_model.train()

        # Fix the batch norm parameters according to the config
        if fix_bn:
            for m in b1_model.modules():
                if isinstance(m, nn.BatchNorm2d):
                    m.eval()

        # Set all the losses to zeros
        train_loss = 0
        train_loss1 = 0
        train_loss2 = 0
        # Set the counters to zeros
        correct = 0
        total = 0
        # Learning rate decay
        tg_lr_scheduler.step()

        # Print the information
        print('\nEpoch: %d, learning rate: ' % epoch, end='')
        print(tg_lr_scheduler.get_lr()[0])

        criterion = nn.CrossEntropyLoss()
        for batch_idx, (inputs, targets) in enumerate(trainloader):
            inputs, targets = inputs.to(device), targets.to(device)
            tg_optimizer.zero_grad()

            if the_args.mixup=='mixup':
                batch_size = inputs.shape[0]
                alpha = 20.0
                index = torch.randperm(batch_size).cuda()
                lam = np.random.beta(alpha, alpha)
                if lam < 0.4 or lam > 0.6:
                    lam = 0.5
                if inputs.shape[0]==128:
                    mix_data=lam * inputs + (1 - lam) * inputs[index, :]
                    inputs=mix_data
                # Get a batch of training samples, transfer them to the device
                inputs, targets = inputs.to(device), targets.to(device)
                # Clear the gradient of the paramaters for the tg_optimizer
                outputs = b1_model(inputs)
                loss1 = lam * criterion(outputs, targets) + (1 - lam) * criterion(outputs, targets[index])
            elif the_args.mixup=='nonemixup':
                outputs = b1_model(inputs)
                loss1=0
            else:
                print('mixup_error')
            # Forward the samples in the deep networks
            if the_args.zeroth_baseline=='cosface':
                features=b1_model.encode(inputs)
                wf = F.linear(F.normalize(features, p=2, dim=1), F.normalize(b1_model.fc.weight, p=2, dim=1))
                classes = the_args.nb_cl_fg + iteration * the_args.nb_cl
                the_args.loss_m = (tenh(1/classes))
                print('the_args.loss_m', the_args.loss_m)
                angular_criterion = AngularPenaltySMLoss(loss_type=the_args.loss_type, s=the_args.loss_s, m=the_args.loss_m)
                loss2 = angular_criterion(wf, targets)
            elif the_args.zeroth_baseline=='cross':
                # Compute classification loss
                outputs = b1_model(inputs)
                loss2 = nn.CrossEntropyLoss(weight_per_class)(outputs, targets)
            else:
                print('zeroth_baseline_error')

            if the_args.mixup=='mixup':
                loss=loss1+loss2
            else:
                loss=loss2
            # Backward and update the parameters
            loss.backward()
            tg_optimizer.step()
            # Record the losses and the number of samples to compute the accuracy
            train_loss += loss.item()
            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

        # Print the training losses and accuracies
        print('Train set: {}, train loss: {:.4f} accuracy: {:.4f}'.format(len(trainloader), train_loss/(batch_idx+1), 100.*correct/total))

        # Running the test for this epoch
        b1_model.eval()
        test_loss = 0
        correct = 0
        total = 0
        with torch.no_grad():
            for batch_idx, (inputs, targets) in enumerate(valloader):
                inputs, targets = inputs.to(device), targets.to(device)
                outputs = b1_model(inputs)
                loss = nn.CrossEntropyLoss(weight_per_class)(outputs, targets)
                test_loss += loss.item()
                _, predicted = outputs.max(1)
                total += targets.size(0)
                correct += predicted.eq(targets).sum().item()
        print('Val set: {} val loss: {:.4f} accuracy: {:.4f}'.format(len(valloader), test_loss/(batch_idx+1), 100.*correct/total))

    return b1_model
