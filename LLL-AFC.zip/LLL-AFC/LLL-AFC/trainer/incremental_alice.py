
from utils.misc import *
from utils.process_fp import process_inputs_fp
from loss.criterion import AngularPenaltySMLoss
import torch.nn.functional as F
from trainer.SimSiam_block import SimSiam
from utils.utils import tenh as tenh
import torch.optim as optim
import math

cur_features = []
ref_features = []
old_scores = []
new_scores = []

def get_ref_features(self, inputs, outputs):
    global ref_features
    ref_features = inputs[0]

def get_cur_features(self, inputs, outputs):
    global cur_features
    cur_features = inputs[0]

def get_old_scores_before_scale(self, inputs, outputs):
    global old_scores
    old_scores = outputs

def get_new_scores_before_scale(self, inputs, outputs):
    global new_scores
    new_scores = outputs

def map_labels(order_list, Y_set):
    map_Y = []
    for idx in Y_set:
        map_Y.append(order_list.index(idx))
    map_Y = np.array(map_Y)
    return map_Y

def incremental_train_and_eval(the_args, epochs, fusion_vars, ref_fusion_vars, b1_model, ref_model, b2_model, ref_b2_model, \
    tg_optimizer, tg_lr_scheduler, fusion_optimizer, fusion_lr_scheduler, trainloader, testloader, valloader, iteration, \
    start_iteration, X_protoset_cumuls, Y_protoset_cumuls, order_list, \
    balancedloader, fix_bn=False, weight_per_class=None, device=None):

    # Setting up the CUDA device
    if device is None:
        device = torch.device("cuda:0" if torch.cuda.is_available() else "gpu")
    # Set the 1st branch reference model to the evaluation mode
    ref_model.eval()

    cos_criterion = nn.CosineSimilarity(dim=1).to(device)
    SimSiam_block_src = SimSiam().to(device)
    SimSiam_block_src_optim = optim.SGD(SimSiam_block_src.parameters(), lr=the_args.base_lr1, momentum=the_args.custom_momentum,
                             weight_decay=the_args.custom_weight_decay)
    SimSiam_block_src.apply(weights_init)
    SimSiam_block_src.to(device)
    SimSiam_block_src.train()

    # Get the features from the current and the reference model
    handle_ref_features = ref_model.fc.register_forward_hook(get_ref_features)
    handle_cur_features = b1_model.fc.register_forward_hook(get_cur_features)
    handle_old_scores_bs = b1_model.fc.fc1.register_forward_hook(get_old_scores_before_scale)
    handle_new_scores_bs = b1_model.fc.fc2.register_forward_hook(get_new_scores_before_scale)

    # If the 2nd branch reference is not None, set it to the evaluation mode
    if iteration > start_iteration+1:
        ref_b2_model.eval()

    for epoch in range(epochs):
        # Start training for the current phase, set the two branch models to the training mode
        b1_model.train()
        b2_model.train()

        # Fix the batch norm parameters according to the config
        if fix_bn:
            for m in b1_model.modules():
                if isinstance(m, nn.BatchNorm2d):
                    m.eval()

        # Set all the losses to zeros
        train_loss = 0
        train_loss1 = 0
        train_loss2 = 0
        train_loss3 = 0
        # Set the counters to zeros
        correct = 0
        total = 0
    
        # Learning rate decay
        tg_lr_scheduler.step()
        fusion_lr_scheduler.step()

        # Print the information
        print('\nEpoch: %d, learning rate: ' % epoch, end='')

        for batch_idx, (inputs, targets) in enumerate(trainloader):

            # Get a batch of training samples, transfer them to the device
            inputs, targets = inputs.to(device), targets.to(device)

            # Clear the gradient of the paramaters for the tg_optimizer
            tg_optimizer.zero_grad()
            SimSiam_block_src.zero_grad()

            # Forward the samples in the deep networks
            outputs, features,f_new1,f_old1,f_new2,f_old2,f_new3,f_old3= process_inputs_fp(the_args, fusion_vars, b1_model, b2_model, inputs)
            p1, p2, z1, z2 = SimSiam_block_src(f_new1, f_old1)
            cl_loss = -(cos_criterion(p1, z2).mean() + cos_criterion(p2, z1).mean()) * 0.5
            loss1=cl_loss

            wf1 = F.linear(F.normalize(features, p=2, dim=1), F.normalize(b1_model.fc.fc1.weight, p=2, dim=1))
            wf2 = F.linear(F.normalize(features, p=2, dim=1), F.normalize(b1_model.fc.fc2.weight, p=2, dim=1))
            wf = torch.cat((wf1, wf2), dim=1).to(device)

            classes = the_args.nb_cl_fg + (iteration-1) * the_args.nb_cl
            if iteration == 1:
                loss_m = tenh(1 / classes)

            if iteration == 2:
                loss_m = tenh(1 / (classes - 2)+ 1 / ((classes - 2)+2*math.log(2)) )

            if iteration == 3:
                loss_m = tenh(1 / (classes-4) + 1 / ((classes - 4)+2*math.log(2)) + 1 / ((classes - 4)+2*math.log(3)))

            if iteration == 4:
                loss_m = tenh(1 / (classes-6) + 1 / ((classes - 6)+2*math.log(2)) + 1 / ((classes - 6)+2*math.log(3))+ 1/ ((classes - 6)+2*math.log(4)) )

            if iteration == 5:
                loss_m = tenh(1 / (classes - 8)+ 1 / ((classes - 8)+2*math.log(2)) + 1 / ((classes - 8)+2*math.log(3))+ 1/ ((classes - 8)+2*math.log(4))+ 1/ ((classes - 8)+2*math.log(5)) )
            angular_criterion = AngularPenaltySMLoss(loss_type=the_args.loss_type, s=the_args.loss_s, m=loss_m)
            angular_loss = angular_criterion(wf, targets)
            loss2 = angular_loss

            loss=loss1+loss2

            # Backward and update the parameters
            loss.backward()
            tg_optimizer.step()
            SimSiam_block_src_optim.step()

            # Record the losses and the number of samples to compute the accuracy
            train_loss += loss.item()
            train_loss1 += loss1.item()
            train_loss2 += loss2.item()

            _, predicted = outputs.max(1)
            total += targets.size(0)
            correct += predicted.eq(targets).sum().item()

        # Print the training losses and accuracies
        print('Train set: {},  train loss: {:.4f} accuracy: {:.4f}'.format(len(trainloader),  train_loss/(batch_idx+1), 100.*correct/total))

        b1_model.eval()
        b2_model.eval()
     
        for batch_idx, (inputs, targets) in enumerate(balancedloader):
            if batch_idx <= 500:
                inputs, targets = inputs.to(device), targets.to(device)
                outputs, _ ,_,_,_,_,_,_= process_inputs_fp(the_args, fusion_vars, b1_model, b2_model, inputs)
                loss = nn.CrossEntropyLoss(weight_per_class)(outputs, targets)
                loss.backward()
                fusion_optimizer.step()

        # Running the test for this epoch
        b1_model.eval()
        b2_model.eval()
        test_loss = 0
        correct = 0
        total = 0
        with torch.no_grad():
            for batch_idx, (inputs, targets) in enumerate(valloader):
                inputs, targets = inputs.to(device), targets.to(device)
                outputs, _ ,_,_,_,_,_,_= process_inputs_fp(the_args, fusion_vars, b1_model, b2_model, inputs)
                loss = nn.CrossEntropyLoss(weight_per_class)(outputs, targets)
                test_loss += loss.item()
                _, predicted = outputs.max(1)
                total += targets.size(0)
                correct += predicted.eq(targets).sum().item()
        print('evalset: {} val loss: {:.4f} accuracy: {:.4f}'.format(len(valloader), test_loss/(batch_idx+1), 100.*correct/total))

    print("Removing register forward hook")
    handle_ref_features.remove()
    handle_cur_features.remove()
    handle_old_scores_bs.remove()
    handle_new_scores_bs.remove()
    return b1_model, b2_model
