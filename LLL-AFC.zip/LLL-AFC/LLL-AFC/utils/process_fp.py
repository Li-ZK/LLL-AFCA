
""" Using the aggregation weights to compute the feature maps from two branches """
from utils.misc import *

def process_inputs_fp(the_args, fusion_vars, b1_model, b2_model, inputs, feature_mode=False):

    # The 1st level
    if the_args.dataset == 'PaviaU'or the_args.dataset == 'Houston13' or the_args.dataset == 'Salinas'or the_args.dataset == 'PaviaC' or the_args.dataset == 'Houston18':
        b1_model_group1 = [b1_model.conv1, b1_model.bn1, b1_model.relu, b1_model.layer1]
        b2_model_group1 = [b2_model.conv1, b2_model.bn1, b2_model.relu, b2_model.layer1]
    else:
        raise ValueError('Please set correct dataset.')
    b1_model_group1 = nn.Sequential(*b1_model_group1)
    b1_fp1 = b1_model_group1(inputs)
    b2_model_group1 = nn.Sequential(*b2_model_group1)
    b2_fp1 = b2_model_group1(inputs)
    fp1 = fusion_vars[0]*b1_fp1+(1-fusion_vars[0])*b2_fp1

    # The 2nd level
    b1_model_group2 = b1_model.layer2
    b1_fp2 = b1_model_group2(fp1)
    b2_model_group2 = b2_model.layer2
    b2_fp2 = b2_model_group2(fp1)
    fp2 = fusion_vars[1]*b1_fp2+(1-fusion_vars[1])*b2_fp2

    # The 3rd level
    if the_args.dataset == 'PaviaU'or the_args.dataset == 'Houston13' or the_args.dataset == 'Salinas'or the_args.dataset == 'PaviaC' or the_args.dataset == 'Houston18':
        b1_model_group3 = [b1_model.layer3, b1_model.avgpool]
        b2_model_group3 = [b2_model.layer3, b2_model.avgpool]
    else:
        raise ValueError('Please set correct dataset.')
    b1_model_group3 = nn.Sequential(*b1_model_group3)
    b1_fp3 = b1_model_group3(fp2)
    b2_model_group3 = nn.Sequential(*b2_model_group3)
    b2_fp3 = b2_model_group3(fp2)
    fp3 = fusion_vars[2]*b1_fp3+(1-fusion_vars[2])*b2_fp3

    if the_args.dataset == 'PaviaU'or the_args.dataset == 'Houston13' or the_args.dataset == 'Salinas'or the_args.dataset == 'PaviaC' or the_args.dataset == 'Houston18':
        fp_final = fp3.view(fp3.size(0), -1)
    else:
        raise ValueError('Please set correct dataset.')
    if feature_mode:
        return fp_final,b1_fp2,b2_fp2
    else:
        outputs = b1_model.fc(fp_final)
        return outputs, fp_final,b1_fp1,b2_fp1,b1_fp2,b2_fp2,b1_fp3,b2_fp3
