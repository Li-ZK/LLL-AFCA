
""" The functions that compute the accuracies """
import torch.nn.functional as F
from scipy.spatial.distance import cdist
from utils.misc import *
from utils.process_fp import process_inputs_fp
from torchmetrics.classification import MulticlassAccuracy
from torchmetrics.classification import MulticlassCohenKappa

def map_labels(order_list, Y_set):
    map_Y = []
    for idx in Y_set:
        map_Y.append(order_list.index(idx))
    map_Y = np.array(map_Y)
    return map_Y

def compute_accuracy(the_args, fusion_vars, b1_model, b2_model, tg_feature_model, class_means, \
                     X_protoset_cumuls, Y_protoset_cumuls, evalloader, order_list, iteration,is_start_iteration=False, \
                     fast_fc=None, scale=None, print_info=True, device=None, cifar=True, imagenet=False, \
                     valdir=None):
    if device is None:
        device = torch.device("cuda:0" if torch.cuda.is_available() else "cpu")
    b1_model.eval()
    tg_feature_model.eval()
    b1_model.eval()
    if b2_model is not None:
        b2_model.eval()

    correct = 0
    correct_ncm = 0
    total = 0
    label_list = []
    num_classes = the_args.nb_cl_fg + iteration * the_args.nb_cl
    print('num_classes',num_classes)
    metric_AA = MulticlassAccuracy(num_classes, average=None).to(device)
    metric_Kappa = MulticlassCohenKappa(num_classes).to(device)
    with torch.no_grad():
        for batch_idx, (inputs, targets) in enumerate(evalloader):

            inputs, targets = inputs.to(device), targets.to(device)
            total += targets.size(0)

            if is_start_iteration:
                outputs = b1_model(inputs)
            else:
                outputs, outputs_feature, _, _, _, _, _, _ = process_inputs_fp(the_args, fusion_vars, b1_model,
                                                                               b2_model, inputs)
            outputs = F.softmax(outputs, dim=1)
            if scale is not None:
                assert (scale.shape[0] == 1)
                assert (outputs.shape[1] == scale.shape[1])
                outputs = outputs / scale.repeat(outputs.shape[0], 1).type(torch.FloatTensor).to(device)
            _, predicted = outputs.max(1)
            correct += predicted.eq(targets).sum().item()
            if is_start_iteration:
                outputs_feature = np.squeeze(tg_feature_model(inputs))
            sqd_ncm = cdist(class_means[:, :, 1].T, outputs_feature.cpu(), 'sqeuclidean')
            score_ncm = torch.from_numpy((-sqd_ncm).T).to(device)
            _, predicted_ncm = score_ncm.max(1)
            correct_ncm += predicted_ncm.eq(targets).sum().item()

            if iteration==8:
                oa=correct / total
                metric_AA.update(predicted, targets)
                metric_Kappa.update(predicted, targets)
            else:
                oa=correct_ncm / total
                metric_AA.update(predicted_ncm, targets)
                metric_Kappa.update(predicted_ncm, targets)

            label_list.extend(predicted_ncm.cpu().numpy())

        print(metric_AA.compute())
        aa = metric_AA.compute()
        aa=aa.cpu()
        class_oa=aa.numpy().tolist()
        print('class_oa',class_oa)
        AA1=aa.mean()
        AA=AA1.item()
        metric_AA.reset()
        kappa=metric_Kappa.compute()
        Kappa1=kappa.mean()
        Kappa = Kappa1.item()
        metric_Kappa.reset()
    if print_info:
        print("  Current accuracy (OA)   :\t\t{:.2f} %".format(100. * oa))
        print("  Current accuracy (AA)   :\t\t{:.2f} %".format(100. * AA))
        print("  Current accuracy (KK)   :\t\t{:.2f} %".format(100. * Kappa))
    ncm_acc = oa
    average_accuracy = AA
    kappa_accuracy = Kappa
    class_OA=class_oa
    return [ncm_acc, average_accuracy, kappa_accuracy,class_OA]


