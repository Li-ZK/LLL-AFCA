import os
import json

def saveFile(path, content):
    file_path, file_name = os.path.split(path)
    if not os.path.exists(file_path):
        os.makedirs(file_path)
    with open(path, 'w') as f:
        f.write(content)

def saveJSONFile(path, save_dict, a=False):
    if a:
        with open(path, 'a') as f:
            f.seek(0)
            try:
                ever = json.loads(f.read())
            except json.JSONDecodeError:
                ever = {}
            save_dict = {**ever, **save_dict}

    saveFile(path, json.dumps(save_dict))